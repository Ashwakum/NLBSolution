﻿using System.ComponentModel.DataAnnotations;
using System.Reflection;

namespace NLBWeb.Models
{
    public class Student
    {
        public string StudentId { get; set; }
        [Required]
        [MinLength(2)]
        public string FirstName { get; set; }
        [Required]
        public string LastName { get; set; }
        public string Age { get; set; }
        public List<Hobbies> Hobbies { get; set; }
 
    }
}
