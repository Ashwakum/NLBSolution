﻿using System.ComponentModel.DataAnnotations;

namespace NLBWebApplication.Models
{
    public class StudentForm
    {
        public string StudentId { get; set; }
        [Required]
        [MinLength(2)]
        public string FirstName { get; set; }
        [Required]
        public string LastName { get; set; }
        public string Age { get; set; }
        public List<string> Hobbies { get; set; }
    }
}
