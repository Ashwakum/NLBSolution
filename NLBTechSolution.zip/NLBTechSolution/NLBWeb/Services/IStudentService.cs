﻿using NLBWeb.Models;

namespace NLBWeb.Services
{
    public interface IStudentService
    {
        Task SubmitFormWirhAZFunction(Student studentForm);
    }
}
