﻿using Microsoft.AspNetCore.Mvc;
using NLBWebApplication.Models;
using System.Text.Json;

namespace NLBWebApplication.Services
{
    public class StudentService : IStudentService
    {

        HttpClient _httpClient = new HttpClient();
        [HttpPost]
        public async Task SubmitFormWithAZFunction(StudentForm studentForm)
        {
            StudentForm studentTemp = new StudentForm();
            studentTemp = studentForm;
            using (var content = new StringContent(JsonSerializer.Serialize(studentTemp), System.Text.Encoding.UTF8, "application/json"))
            {
                HttpResponseMessage httpResponse = await _httpClient.PostAsync("/api/StudentForm", content);
                string returnValue = httpResponse.Content.ReadAsStringAsync().Result;

            }


        }
    }
}
