﻿using NLBWebApplication.Models;

namespace NLBWebApplication.Services
{
   
    public interface IStudentService
    {
        Task SubmitFormWithAZFunction(StudentForm studentForm);
    }
}
