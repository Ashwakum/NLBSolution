﻿using Microsoft.AspNetCore.Components;
using NLBWeb.Models;
using System.ComponentModel.DataAnnotations;
using System.Text.Json;

namespace NLBWeb.Pages
{
    public class IndexBase: ComponentBase
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }

        [MaxLength(100)]
        public string Age { get; set; }
        public Hobbies StudentHobbies { get; set; }

        HttpClient _httpClient = new HttpClient();

        public async Task SubmitForm()
        {
            Student studentForm = new Student();
            studentForm.StudentId = Guid.NewGuid().ToString(); ;
            studentForm.FirstName = FirstName;
            studentForm.LastName = LastName;
            studentForm.Age = Age;
            //studentForm.Hobbies = StudentHobbies.;
            //await newLetterFormService.SubmitFormWirhAZFunction(employeeNewsletterForm);

            using (var content = new StringContent(JsonSerializer.Serialize(studentForm), System.Text.Encoding.UTF8, "application/json"))
            {
                HttpResponseMessage httpResponse = await _httpClient.PostAsync("/api/Function1", content);
                string returnValue = httpResponse.Content.ReadAsStringAsync().Result;

            }

            //Name = string.Empty; Email = string.Empty; MobileNumber = string.Empty;



        }
    }
}
