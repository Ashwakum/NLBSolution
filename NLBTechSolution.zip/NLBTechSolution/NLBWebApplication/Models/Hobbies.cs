﻿namespace NLBWebApplication.Models
{
    public class Hobbies
    {
        public string StudentHobby { get; set; }
    }
}
