﻿using Microsoft.AspNetCore.Components;
using Microsoft.JSInterop;
using NLBWebApplication.Models;
using System.ComponentModel.DataAnnotations;
using System.Reflection;
using System.Text.Json;
using CurrieTechnologies.Blazor.SweetAlert2;
using System;


namespace NLBWebApplication.Pages
{
    public class Indexbase : ComponentBase
    {
        //[Inject] SweetAlertService Swal { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }

        [MaxLength(100)]
        public string Age { get; set; }
        public string StudentHobbies1 { get; set; }
        public string StudentHobbies2 { get; set; }
        public string StudentHobbies3 { get; set; }

        HttpClient _httpClient = new HttpClient();

        public async Task SubmitForm()
        {
            StudentForm studentForm = new StudentForm();
            studentForm.StudentId = Guid.NewGuid().ToString(); ;
            studentForm.FirstName = FirstName;
            studentForm.LastName = LastName;
            studentForm.Age = Age;
            //List<Hobbies> hobbies = new List<Hobbies>
            //{
            //    new Hobbies { StudentHobby = StudentHobbies1==string.Empty?"Null":StudentHobbies3},
            //    new Hobbies { StudentHobby = StudentHobbies2==string.Empty?"Null":StudentHobbies3},
            //    new Hobbies { StudentHobby = StudentHobbies3==string.Empty?"Null":StudentHobbies3}
            //};
            List<string> hobbies = new List<string>
            {StudentHobbies1, StudentHobbies2, StudentHobbies3 };
            studentForm.Hobbies = hobbies;
            using (var content = new StringContent(JsonSerializer.Serialize(studentForm), System.Text.Encoding.UTF8, "application/json"))
            {
                string returnValue = "";
                HttpResponseMessage httpResponse = await _httpClient.PostAsync("http://localhost:7240/api/Function1", content);
                returnValue = httpResponse.Content.ReadAsStringAsync().Result;
                FirstName = "";
                LastName = "";
                Age = "";
                StudentHobbies1 = "";
                StudentHobbies2 = "";
                StudentHobbies3 = "";

            }
        }
    }
}
