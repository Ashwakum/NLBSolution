﻿namespace NLBWeb.Services
{
    public class Hobbies
    {
        public string StudentHobbies { get; set; }

    }
}
