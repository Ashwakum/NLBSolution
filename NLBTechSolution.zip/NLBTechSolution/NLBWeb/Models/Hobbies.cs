﻿namespace NLBWeb.Models
{
    public class Hobbies
    {
    }
}
