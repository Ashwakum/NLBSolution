using System;
using System.IO;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.AspNetCore.Http;
using Microsoft.Azure.WebJobs.Host;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using NLBWebApplication.Models;

namespace StudentFunctionApp
{
    public static class Function1
    {
        [FunctionName("Function1")]
        public static async Task<IActionResult> Run(
            [HttpTrigger(AuthorizationLevel.Function, "get", "post")] HttpRequest request,
            [Queue("StudentInBound",Connection = "AzureWebJobsStorage")]
             IAsyncCollector<StudentForm> myQueueItem, ILogger log)
        {
            log.LogInformation($"C# Queue trigger function processed: {myQueueItem}");

            string requestBody = await new StreamReader(request.Body).ReadToEndAsync();
            StudentForm data = JsonConvert.DeserializeObject<StudentForm>(requestBody);

            await myQueueItem.AddAsync(data);

            string message = $"Epic{data}";

            return new OkObjectResult(message);
        }
    }
}
